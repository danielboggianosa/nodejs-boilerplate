import {Request, Response} from 'express';
import Usuario from '../models/Usuario';

class IndexController{
    
    
    //CREATE
    public async create(req:Request, res:Response): Promise<void>{
        res.json({message: 'Accediendo al método CREAR'});
    }
    
    //READ
    public async read(req:Request, res:Response): Promise<void>{
        if(Usuario) res.render('index',{database:true})
        else res.render('index')
    }
    
    //UPDATE
    public async update(req:Request, res:Response): Promise<void>{
        res.json({message: 'Accediendo al método ACTUALIZAR'});
    }
    
    //DELTE
    public async delete(req:Request, res:Response): Promise<void>{
        res.json({message: 'Accediendo al método BORRAR'});
    }
}
const indexController = new IndexController();
export default indexController;