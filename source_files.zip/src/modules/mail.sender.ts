 
import nodemailer, { Transport, TransportOptions, Transporter } from 'nodemailer'
import tokenSecure from './token.secure'
import dotenv from 'dotenv'
import SMTPTransport from 'nodemailer/lib/smtp-transport';

class MailSender {

    
    transporter:Transporter;
    options:SMTPTransport.Options;
    server={
        correo: process.env.MAIL_SERVER, // en este caso correo está configurada con una variable de entorno
        pass: process.env.MAIL_SERVER_PASS, // en este caso la contraseña está configurada con una variable de entorno
    }

    constructor(){
        dotenv.config()
        this.options={
            host: process.env.MAIL_SERVER,
            port: 587,
            secure: false, // upgrade later with STARTTLS
            auth: {
                user: process.env.MAIL_SERVER_USER,
                pass: process.env.MAIL_SERVER_PASS
            }
        }
        this.transporter = nodemailer.createTransport(this.options);
    }
    
    test(){
        // verify connection configuration
        this.transporter.verify(function(error: any, success: any) {
            if (error) {
                console.log(error);
            } else {
                console.log("Server is ready to take our messages");
            }
        });
  
    }   
    
    async recoverPass(correo:string){
        await tokenSecure.generar({correo})
        .then(token => {
            let message={
                from: this.server.correo,
                to: correo,
                subject: 'Recuperar Contraseña',
                html: 'Hola, has solicitado recuperar tu contraseña. Para recuperarla ve al siguiente enlace: <a href="'+process.env.SITE_URL+'/reset/'+token+'">click aquí</a>',            
            }
            this.transporter.sendMail(message)
        })
    }
      

}
const mailSender = new MailSender();
export default mailSender;