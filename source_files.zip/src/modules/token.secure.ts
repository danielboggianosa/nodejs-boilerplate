import jwt from 'jsonwebtoken'
import {Request, Response, NextFunction} from 'express'
import dotenv from 'dotenv'

class TokenSecure {

    secret:string

    constructor(){
        dotenv.config()
        this.secret = process.env.SECRET_KEY || ""
    }

    public generar(data:object){
        return new Promise((resolve,reject)=>{
            // "env" esta es un variable guardada en un archivo secreto, puedes cambiarla por la que tú desees
            
            const token = jwt.sign(data, this.secret, {expiresIn: '5h'});
            if(token) resolve(token)
            else reject('no se pudo generar el token')
        })
    }

    public proteger(req: Request, res: Response, next: NextFunction){
        const bearerHeader = req.headers['authorization'];
        if( typeof bearerHeader !== 'undefined'){
            const token = bearerHeader.split(' ')[1]
            jwt.verify(token, this.secret, (err:any, data:any)=>{
                if(data) {
                    let now = new Date()
                    let exp = new Date(data.exp*1000)
                    if(now < exp){
                        next()
                    }
                    else res.sendStatus(403).json({message:'token expirado'})
                }
                else res.sendStatus(403)
            })
        }
        else res.sendStatus(403)
    }
}

const tokenSecure = new TokenSecure();
export default tokenSecure;