import bcrypt, { hash } from 'bcrypt'
import dotenv from 'dotenv'

class CryptoSecure {
    
    constructor(){
        dotenv.config()
    }
    
    public encriptar(password:string){
        return new Promise((resolve,reject) => {
            bcrypt.hash(password,process.env.ROUNDS || 11,(err:any,hash:any)=>{
                if(hash) resolve(hash)
                else reject(err)
            })
        })
    }

    public comparar(password:string, hashed:string){
        return new Promise((resolve,reject)=>{
            bcrypt.compare(password,hashed,(err,res)=>{
                if(res) resolve(res)
                else reject('password mismatch')
            })
        })
    }

}
const cryptoSecure = new CryptoSecure();
export default cryptoSecure;