import connection from "./connection";

class Database{

    constructor(){
        this.config()
    }

    config(){
        connection.on('error', console.error.bind(console, 'connection error:'));
        connection.once('open', ()=>console.log("conectado a la base de datos"))
    }

}

const database = new Database()
export default database 