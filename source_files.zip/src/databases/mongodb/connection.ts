import mongoose from 'mongoose'
import dotenv from 'dotenv'
dotenv.config
const{
    DB_USER,
    DB_PASS,
    DB_HOST,
    DB_PORT,
    DB_NAME
}=process.env

mongoose.connect(`mongodb://${DB_HOST}/${DB_NAME}`, {useNewUrlParser: true, useUnifiedTopology: true})
const connection = mongoose.connection;

export default connection