import dotenv from 'dotenv'
import { Sequelize } from 'sequelize'
dotenv.config()
const connection = new Sequelize(
    // estas variables se pueden encontrar en el archivo .env en el directorio raíz
    process.env.DB_NAME || "", 
    process.env.DB_USER || "", 
    process.env.DB_PASS || "",
    {
        host: process.env.DB_HOST,
        logging: false, // evita mostrar consulta SLQ en la consola
        dialect: "mysql",
        dialectOptions: {
            timezone: '-05:00'
        },
        pool: {
            max: 5,
            min: 0,
            acquire: 30000,
            idle: 10000
        },
        define: {
            timestamps: true, //crea campos de tiempos de creación y actualización en cada tabla
            paranoid: true // En lugar de borrar los registros, añade el tiempo en el que fue borrado
        }
    }
);
export default connection;