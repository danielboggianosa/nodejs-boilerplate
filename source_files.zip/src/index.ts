import express from 'express'
import {Application} from 'express-serve-static-core'
import morgan from 'morgan'
import cors from 'cors'
import indexRoutes from './routes/index.routes'
import dotenv from 'dotenv'
import database from './database/mysql/config'

class Servidor{
    public app: Application

    constructor(){
        this.app = express()
        this.config()
        this.routes()
    }
    
    config(){
        dotenv.config()
        if(database)
            database.config()
        this.app.set('port', process.env.PORT);
        this.app.set('view engine', 'pug');
        this.app.use(morgan('dev'));
        this.app.use(cors());
        this.app.use(express.json());
        this.app.use(express.urlencoded({extended:false}));
    }

    routes():void{
        this.app.use('/', indexRoutes);
    }

    start():void{
        this.app.listen(this.app.get('port'), ()=>console.log('Servidor en el puerto', this.app.get('port')))
    }
}
const servidor = new Servidor()
servidor.start()