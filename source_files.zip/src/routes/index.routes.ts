import {Router} from 'express';
import indexController from '../controllers/index.controllers';

class IndexRoutes{
    public router: Router = Router();

    constructor(){
        this.config();
    }

    config(){
        this.router.post('/', indexController.create)
        this.router.get('/', indexController.read)
        this.router.put('/', indexController.update)
        this.router.delete('/', indexController.delete)
    }
}
const indexRoutes = new IndexRoutes();
export default indexRoutes.router;