import connection from '../database/connection';
import Sequelize from 'sequelize';

//ejemplo para definir una tabla llamada "usuarios" y sus atributos. Tomar en cuenta que el campo id se genera automáticamente a menos que se especifique.

const Usuario = connection.define('usuario', {
    nombre: {
      type: Sequelize.STRING,
      allowNull: false,
      field: 'nombre'
    },
    apellido: {
      type: Sequelize.STRING,
      field: 'apellido'
    },
    correo: {
      type: Sequelize.STRING,
      allowNull: false,
      unique: true,
      field: 'correo'
    },
    imagen: {
      type: Sequelize.STRING,
      field: 'imagen'
    },
    password: {
      type: Sequelize.STRING,
      allowNull: false,
      field: 'password'
    }
  }, { tableName: 'usuarios' });

  export default Usuario;
