import mongoose from "mongoose";

const UsuarioShchema = new mongoose.Schema({
  nombre:String,
  apellido:String,
  correo:String,
  password:String
})
const Usuario = mongoose.model('Usuario', UsuarioShchema)
export default Usuario